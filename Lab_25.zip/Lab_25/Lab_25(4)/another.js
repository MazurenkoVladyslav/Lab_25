function greet() {
    console.log("Hello from another.js");
}

module.exports = greet;

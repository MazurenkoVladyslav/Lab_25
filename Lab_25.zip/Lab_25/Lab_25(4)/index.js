const greet = require('./another');
greet();
